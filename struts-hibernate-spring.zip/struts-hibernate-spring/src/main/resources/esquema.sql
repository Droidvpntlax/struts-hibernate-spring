drop table if exist persona;

create table persona (
	id_persona identity primary key,
	nombre varchar(50) not null,
	ape_paterno varchar(50) not null,
	ape_materno varchar(50) not null,
	email varchar(50) not null,
	);